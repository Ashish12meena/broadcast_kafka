package com.aigreentick.services.broadcast.infrastructure.kafka.publisher;

import com.aigreentick.services.broadcast.common.constants.InfraConstants;
import com.aigreentick.services.broadcast.common.constants.ObservabilityConstants;
import com.aigreentick.services.broadcast.common.util.LogSafe;
import com.aigreentick.services.broadcast.application.port.out.DeadLetterPort;
import com.aigreentick.services.broadcast.infrastructure.config.BroadcastProperties;
import com.aigreentick.services.broadcast.infrastructure.observability.BroadcastMetrics;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * Sets aside messages that cannot be processed.
 *
 * <p>The alternative — acknowledging and moving on — loses up to a full batch of recipients with no
 * record that they existed, which is discovered later only as a campaign whose numbers do not add
 * up. Keeping the original bytes and the reason on a dead letter topic makes the problem
 * inspectable and the messages replayable once the cause is fixed.
 */
@Component
public class DeadLetterEventPublisher implements DeadLetterPort {

    private static final Logger log = LoggerFactory.getLogger(DeadLetterEventPublisher.class);

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final BroadcastProperties properties;
    private final BroadcastMetrics metrics;

    public DeadLetterEventPublisher(
            KafkaTemplate<String, String> kafkaTemplate,
            BroadcastProperties properties,
            BroadcastMetrics metrics) {
        this.kafkaTemplate = kafkaTemplate;
        this.properties = properties;
        this.metrics = metrics;
    }

    @Override
    public void send(String rawPayload, String reason, String sourceTopic, int partition, long offset) {
        ProducerRecord<String, String> record = new ProducerRecord<>(
                properties.topics().deadLetter(), null, rawPayload);

        record.headers()
                .add(header(InfraConstants.Kafka.HEADER_DLQ_REASON, reason))
                .add(header(InfraConstants.Kafka.HEADER_DLQ_SOURCE_TOPIC, sourceTopic))
                .add(header(InfraConstants.Kafka.HEADER_DLQ_PARTITION, String.valueOf(partition)))
                .add(header(InfraConstants.Kafka.HEADER_DLQ_OFFSET, String.valueOf(offset)))
                .add(header(InfraConstants.Kafka.HEADER_DLQ_TIMESTAMP,
                        String.valueOf(System.currentTimeMillis())));

        try {
            kafkaTemplate.send(record)
                    .get(InfraConstants.Kafka.DEAD_LETTER_PUBLISH_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            metrics.deadLettered(shortReason(reason));
            log.warn("Dead-lettered a message from {}-{} offset {}: {}",
                    sourceTopic, partition, offset, reason);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Interrupted while dead-lettering a message", e);
        } catch (Exception e) {
            // Nowhere left to put it, but the payload still does not go in the log: it is a list of
            // recipients, and every one is a phone number belonging to a real person. The message is
            // recoverable without it — the source topic still holds the bytes and the coordinates
            // below say exactly where. The fingerprint is enough to confirm two occurrences are the
            // same message, which is all the payload was ever needed for here.
            log.error("Could not dead-letter a message from {}-{} offset {} fingerprint={} bytes={}",
                    sourceTopic, partition, offset,
                    LogSafe.fingerprint(rawPayload),
                    rawPayload == null ? 0 : rawPayload.length(), e);
        }
    }

    private static RecordHeader header(String key, String value) {
        return new RecordHeader(key, value == null ? new byte[0] : value.getBytes(StandardCharsets.UTF_8));
    }

    /** Keeps the metric tag to a bounded set of values rather than one per exception message. */
    private static String shortReason(String reason) {
        if (reason == null) {
            return ObservabilityConstants.Metrics.DEAD_LETTER_REASON_UNKNOWN;
        }
        return reason.startsWith(ObservabilityConstants.Metrics.DEAD_LETTER_REASON_DESERIALIZATION)
                ? ObservabilityConstants.Metrics.DEAD_LETTER_REASON_DESERIALIZATION
                : ObservabilityConstants.Metrics.DEAD_LETTER_REASON_VALIDATION;
    }
}
