package com.aigreentick.services.broadcast.infrastructure.redis;

import com.aigreentick.services.broadcast.common.constants.InfraConstants;
import com.aigreentick.services.broadcast.application.port.out.IdempotencyPort;
import com.aigreentick.services.broadcast.infrastructure.config.BroadcastProperties;
import com.aigreentick.services.broadcast.infrastructure.observability.RedisDegradationTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * Stops the same recipient being sent to twice after a redelivery.
 *
 * <p>Meta's messages endpoint has no idempotency key, so the claim has to be taken before the call.
 * Deduplicating afterwards on the returned wamid protects the database but not the customer, who has
 * already received a second copy.
 *
 * <h2>The trade-off, stated plainly</h2>
 * A crash between claiming and sending means that recipient is skipped when Kafka redelivers the
 * batch, and is recovered later by the Messaging Service's stuck-processing cleanup. That is a
 * delayed message. The alternative arrangement produces a duplicate message, which cannot be
 * recovered at all. This implementation prefers the delay, and the choice is configurable via
 * {@code broadcast.idempotency.enabled} because it is a product decision rather than a technical one.
 *
 * <h2>Failing open when Redis is down</h2>
 * If the claim cannot be taken, the send proceeds. Refusing to send during a Redis outage would stop
 * the platform to prevent a duplicate that only occurs on the much rarer redelivery path.
 *
 * <p>{@code claim} runs once per recipient, so a per-failure log line here means one line per
 * recipient for the whole outage — at eighty sends per second per number that is a flood arriving
 * precisely when the log pipeline is needed for something else. The failure is logged as a
 * transition instead.
 */
@Component
public class RedisIdempotencyGuard implements IdempotencyPort {

    private static final Logger log = LoggerFactory.getLogger(RedisIdempotencyGuard.class);

    private final StringRedisTemplate redis;
    private final BroadcastProperties properties;

    private final RedisDegradationTracker degradation =
            new RedisDegradationTracker(log, "the idempotency guard");

    public RedisIdempotencyGuard(StringRedisTemplate redis, BroadcastProperties properties) {
        this.redis = redis;
        this.properties = properties;
    }

    @Override
    public boolean claim(Long recipientId) {
        if (!properties.idempotency().enabled() || recipientId == null) {
            return true;
        }
        try {
            Boolean acquired = redis.opsForValue().setIfAbsent(
                    RedisKeys.sentClaim(recipientId),
                    InfraConstants.Redis.CLAIM_MARKER,
                    properties.idempotency().claimTtl());
            degradation.exit();
            return Boolean.TRUE.equals(acquired);

        } catch (DataAccessException e) {
            // Failing open is the deliberate choice documented above. What must not happen is one
            // log line per recipient while it lasts.
            degradation.enter(e.toString() + "; sends proceed unguarded");
            return true;
        }
    }

    @Override
    public void release(Long recipientId) {
        if (!properties.idempotency().enabled() || recipientId == null) {
            return;
        }
        try {
            redis.delete(RedisKeys.sentClaim(recipientId));
        } catch (DataAccessException e) {
            // The claim expires on its own. Losing this only delays a legitimate retry.
            log.debug("Could not release claim recipientId={} reason={}", recipientId, e.toString());
        }
    }

    @Override
    public String claimedMessageId(Long recipientId) {
        if (!properties.idempotency().enabled() || recipientId == null) {
            return null;
        }
        try {
            String value = redis.opsForValue().get(RedisKeys.sentClaim(recipientId));
            // The bare marker means the claim was taken but confirm() never ran — an in-flight
            // send, or one that failed before it got a wamid. Either way there is no id to report.
            return InfraConstants.Redis.CLAIM_MARKER.equals(value) ? null : value;

        } catch (DataAccessException e) {
            log.debug("Could not read claim recipientId={} reason={}", recipientId, e.toString());
            return null;
        }
    }

    @Override
    public void confirm(Long recipientId, String providerMessageId) {
        if (!properties.idempotency().enabled() || recipientId == null || providerMessageId == null) {
            return;
        }
        try {
            redis.opsForValue().set(
                    RedisKeys.sentClaim(recipientId), providerMessageId, properties.idempotency().claimTtl());
        } catch (DataAccessException e) {
            log.debug("Could not confirm claim recipientId={} reason={}", recipientId, e.toString());
        }
    }

    /** Exposed for {@code CapacityHealthIndicator} and for tests. */
    public boolean isDegraded() {
        return degradation.isDegraded();
    }
}